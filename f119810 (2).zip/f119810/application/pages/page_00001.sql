prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>35903684819454091280
,p_default_application_id=>119810
,p_default_id_offset=>0
,p_default_owner=>'WKSP_EJEM'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(3409514115076981887)
,p_name=>'Inicio'
,p_alias=>'HOME'
,p_step_title=>'Ayudante financiero'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-PageBody {',
'background-image:url(https://images.pexels.com/photos/2098427/pexels-photo-2098427.jpeg?cs=srgb&dl=pexels-eberhard-grossgasteiger-2098427.jpg&fm=jpg);',
'background-repeat: no-repeat;',
'background-size : cover;',
'background-position: center;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>Describe el problema</p>',
unistr('<p>\00BFQu\00E9 puedes facturar?</p>'),
unistr('<P>\00BFC\00F3mo funciona la aplicaci\00F3n?</p>'),
'<P>Asistencia contable</p>',
unistr('<p>Periodos y a\00F1os fiscales</p>'),
'<p>Suma y balance de deducibles</p>'))
,p_last_updated_by=>'DAL_18_ROS@HOTMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20211024143430'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3395893550540626503)
,p_plug_name=>'Nuevo'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--displaySubtitle:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--cols:t-Cards--desc-2ln:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_api.id(3409369482134981819)
,p_plug_display_sequence=>20
,p_list_id=>wwv_flow_api.id(3412157939966144521)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_api.id(3409465192710981861)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
