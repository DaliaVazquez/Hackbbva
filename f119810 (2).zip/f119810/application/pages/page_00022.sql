prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>35903684819454091280
,p_default_application_id=>119810
,p_default_id_offset=>0
,p_default_owner=>'WKSP_EJEM'
);
wwv_flow_api.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_api.id(3409514115076981887)
,p_name=>'tes'
,p_alias=>'TES'
,p_step_title=>'tes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'DAL_18_ROS@HOTMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20211024100015'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(5417172631325364911)
,p_plug_name=>'Informe 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(3409363715696981817)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'AREAS'
,p_query_where=>'areas=''Viaticos'''
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_prn_page_header=>'Informe 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(5417173090593364911)
,p_name=>'Informe 1'
,p_max_row_count_message=>unistr('El recuento m\00E1ximo de filas de este informe es #MAX_ROW_COUNT# filas. Aplique un filtro para reducir el n\00FAmero de registros de la consulta.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:RP:P23_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Editar"><span class="fa fa-edit" aria-hidden="true" title="Editar"></span></span>'
,p_owner=>'DAL_18_ROS@HOTMAIL.COM'
,p_internal_uid=>5417173090593364911
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5417173137839364911)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5417173585522364912)
,p_db_column_name=>'AREAS'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Areas'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(5417173960202364912)
,p_db_column_name=>'VALOR'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(5417315865731365881)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'54173159'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:AREAS:VALOR'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(5417175383498364913)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(5417172631325364911)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(3409489314440981874)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:23:&SESSION.::&DEBUG.:23'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(5417174322153364912)
,p_name=>unistr('Editar Informe: Cuadro de Di\00E1logo Cerrado')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(5417172631325364911)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(5417174835322364912)
,p_event_id=>wwv_flow_api.id(5417174322153364912)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(5417172631325364911)
);
wwv_flow_api.component_end;
end;
/
