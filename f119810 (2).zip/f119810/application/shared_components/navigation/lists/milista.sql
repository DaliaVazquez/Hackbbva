prompt --application/shared_components/navigation/lists/milista
begin
--   Manifest
--     LIST: miLista
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0-18'
,p_default_workspace_id=>35903684819454091280
,p_default_application_id=>119810
,p_default_id_offset=>0
,p_default_owner=>'WKSP_EJEM'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(3412157939966144521)
,p_name=>'miLista'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5140151634144763730)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Tiket'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(5140169118375770465)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Factura'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
